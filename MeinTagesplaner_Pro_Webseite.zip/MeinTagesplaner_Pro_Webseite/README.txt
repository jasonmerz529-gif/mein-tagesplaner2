Mein Tagesplaner – professionelle Landingpage
Die Webseite ist als einzelne index.html aufgebaut und für Desktop und Smartphone optimiert.
Für die Veröffentlichung: index.html auf einen Webhoster hochladen und die Domain darauf zeigen lassen.
Der Download-Button ist derzeit ein Platzhalter und kann später mit der APK oder dem Google-Play-Eintrag verknüpft werden.
